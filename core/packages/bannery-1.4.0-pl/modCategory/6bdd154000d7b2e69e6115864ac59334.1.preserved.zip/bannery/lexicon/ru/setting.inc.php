<?php

$_lang['area_bannery_main'] = 'Основное';

$_lang['setting_bannery_click'] = 'Переменная для учета клика';
$_lang['setting_bannery_click_desc'] = 'Укажите переменную, по которой нужно учитывать, что произошел клик по банеру.';

$_lang['setting_bannery_media_source'] = 'Источник файлов';
$_lang['setting_bannery_media_source_desc'] = 'Источник файлов по умолчанию для изображений баннеров';
