<?php

$_lang['area_bannery_main'] = 'Main';

$_lang['setting_bannery_click'] = 'Banner click variable';
$_lang['setting_bannery_click_desc'] = 'Specify the variable on which you need to consider that there was a click on the banner.';

$_lang['setting_bannery_media_source'] = 'Media source';
$_lang['setting_bannery_media_source_desc'] = 'Default media source for banners images';