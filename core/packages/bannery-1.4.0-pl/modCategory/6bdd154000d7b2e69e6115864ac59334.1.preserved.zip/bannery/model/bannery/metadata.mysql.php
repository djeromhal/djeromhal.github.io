<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'byAd',
    1 => 'byPosition',
    2 => 'byAdPosition',
    3 => 'byClick',
  ),
);