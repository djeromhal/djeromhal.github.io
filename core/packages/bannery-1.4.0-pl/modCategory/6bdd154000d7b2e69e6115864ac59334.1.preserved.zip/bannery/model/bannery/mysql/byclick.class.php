<?php
require_once (dirname(dirname(__FILE__)) . '/byclick.class.php');
class byClick_mysql extends byClick {}