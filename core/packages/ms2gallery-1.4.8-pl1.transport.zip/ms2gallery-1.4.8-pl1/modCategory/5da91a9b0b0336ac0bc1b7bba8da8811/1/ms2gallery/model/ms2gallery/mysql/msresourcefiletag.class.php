<?php
require_once (dirname(dirname(__FILE__)) . '/msresourcefiletag.class.php');
class msResourceFileTag_mysql extends msResourceFileTag {}