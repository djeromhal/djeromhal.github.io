<?php
require_once (dirname(dirname(__FILE__)) . '/msresourcefile.class.php');
class msResourceFile_mysql extends msResourceFile {}