<?php
class msResourceFileTag extends xPDOObject {}