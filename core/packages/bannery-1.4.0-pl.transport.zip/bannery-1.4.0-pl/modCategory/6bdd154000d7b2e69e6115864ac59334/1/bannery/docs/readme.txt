BannerY - manage your ads

Simple and handy way to manage your banner ads. Also this can be used without images, as only-text ads.

it is fork from Jeroen Kenters BannerX with some good new features.