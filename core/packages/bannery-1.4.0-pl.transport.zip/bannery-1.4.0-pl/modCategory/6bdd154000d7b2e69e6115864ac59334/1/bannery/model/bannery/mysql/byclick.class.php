<?php
require_once (dirname(__DIR__) . '/byclick.class.php');
class byClick_mysql extends byClick {}