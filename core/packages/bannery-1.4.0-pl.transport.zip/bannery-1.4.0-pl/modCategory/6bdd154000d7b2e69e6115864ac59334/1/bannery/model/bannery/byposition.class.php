<?php
class byPosition extends xPDOSimpleObject {}