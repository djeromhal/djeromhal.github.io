<?php
class PositionCreateProcessor extends modObjectCreateProcessor {
    public $classKey = 'byPosition';
    public $languageTopics = array('bannery:default');
    public $objectType = 'bannery.position';
}
return 'PositionCreateProcessor';