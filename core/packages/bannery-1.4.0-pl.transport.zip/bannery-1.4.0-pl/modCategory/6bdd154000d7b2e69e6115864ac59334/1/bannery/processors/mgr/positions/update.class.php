<?php
class PositionUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'byPosition';
    public $languageTopics = array('bannery:default');
    public $objectType = 'bannery.position';
}
return 'PositionUpdateProcessor';